// Run: node tests/logic.test.js  (executes the real accounting + parser code from index.html)
const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(__dirname+'/../index.html','utf8').split('<script>')[1].split('</script>')[0];
const store={};const el=()=>({innerHTML:'',classList:{remove(){},toggle(){}},querySelector:()=>el()});
const ctx={document:{getElementById:()=>el(),querySelector:()=>el(),documentElement:{}},localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v},window:{scrollTo(){}},crypto:{randomUUID:()=>Math.random().toString(36).slice(2)+Date.now()},console,Number,Math,JSON,Date,Object};
vm.createContext(ctx);vm.runInContext(src+';this.api={get DB(){return DB},set DB(v){DB=v},createOrder,cancelOrder,confirmPending,addPayment,bal,parse,applyOps,newDraft,seed,toP,prod,cust,save,uid,totalP};',ctx);
const A=ctx.api;let pass=0,fail=0;const ok=(n,c)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
const draft=(text,base)=>{const d=base||A.newDraft();const r=A.parse(text),o=A.applyOps(d.items,r.ops);d.items=o.items;d.clar=r.clar;return d};
const rice=A.DB.products[0];
// customers/products
A.DB.customers.push({id:'c9',name:'Test',phone:'9000000001',address:'',archived:false});ok('1 add customer',!!A.cust('c9'));
A.cust('c9').name='Test2';ok('2 edit customer',A.cust('c9').name==='Test2');
A.DB.products.push({id:'pz',name:'Biscuit',aliases:['biscuit'],unit:'packet',price:1000,stock:10,cat:'',active:true});ok('3 add product',!!A.prod('pz'));
// parsing
let d=draft('rendu kilo arisi, oru litre oil, moonu packet milk');ok('7a Tamil (romanised) = ₹330',A.totalP(d.items)===33000&&d.items.length===3);
d=draft('दो किलो चावल और एक लीटर तेल');ok('7b Hindi native script',d.items.length===2&&d.items[0].qty===2);
d=draft('இரண்டு கிலோ அரிசி');ok('7c Tamil native script',d.items[0].qty===2&&d.items[0].name==='Rice');
d=draft('ಎರಡು ಅಕ್ಕಿ');ok('7d Kannada native script',d.items[0]&&d.items[0].qty===2);
d=draft('రెండు బియ్యం');ok('7e Telugu native script',d.items[0]&&d.items[0].qty===2);
d=draft('2 kg rice and 1 litre oil');ok('7f English',A.totalP(d.items)===27000);
d=draft('rendu kilo rice and ek litre tel');ok('8 mixed language',d.items.length===2&&d.items[0].qty===2&&d.items[1].qty===1);
d=draft('moonu packet milk',draft('rendu kilo arisi'));ok('9 add to existing draft',d.items.length===2);
d=draft('remove milk',d);ok('10 remove item',d.items.length===1);
d=draft('make rice five kilos',d);ok('11 modify quantity',d.items[0].qty===5);
d=draft('two kilos sugar');ok('12a ambiguous → clarification, nothing added',d.items.length===0&&d.clar.length===1);
d=draft('two kilos brown sugar');ok('12b disambiguated',d.items.length===1&&d.items[0].name==='Brown Sugar');
d=draft('rice');ok('12c missing quantity → clarification',d.items.length===0&&d.clar[0].includes('Quantity'));
// orders & accounting
const b0=A.bal('c1');d=draft('rendu kilo arisi, oru litre oil, moonu packet milk');d.cid='c1';d.pay='credit';
let r=A.createOrder(d);ok('13 confirm credit order',!!r.order&&r.order.total===33000);
ok('16 credit sale → exactly one ledger entry',A.DB.ledger.filter(e=>e.oid===r.order.id).length===1&&A.bal('c1')===b0+33000);
ok('14 duplicate order blocked',!!A.createOrder(d).error);
const n=A.DB.ledger.length;let d2=draft('ek kilo atta');d2.pay='cash';r=A.createOrder(d2);ok('15 cash sale recorded, balance unchanged',!!r.order&&A.bal('c1')===b0+33000&&A.DB.ledger.length===n+1&&A.DB.ledger.at(-1).type==='cash_sale');
const oc=r.order.id;
ok('17 partial payment reduces balance',!A.addPayment('c1',10000,'k1','').error&&A.bal('c1')===b0+23000);
ok('duplicate payment blocked',!!A.addPayment('c1',10000,'k1','').error);
ok('invalid payment rejected',!!A.addPayment('c1',0,'k2','').error&&!!A.addPayment('c1',-5,'k3','').error);
ok('18 full payment → zero',!A.addPayment('c1',A.bal('c1'),'k4','').error&&A.bal('c1')===0);
ok('overpayment → advance (negative balance)',!A.addPayment('c1',5000,'k5','').error&&A.bal('c1')===-5000);
ok('credit order needs customer',!!A.createOrder(Object.assign(draft('ek kilo atta'),{pay:'credit',cid:''})).error);
// cancel
const d3=draft('ek kilo toor dal');d3.cid='c2';d3.pay='credit';const bb=A.bal('c2'),st=A.prod(A.DB.products[6].id).stock;const o3=A.createOrder(d3).order;
ok('20a credit cancel reverses balance + stock',!A.cancelOrder(o3.id,'test').error&&A.bal('c2')===bb&&A.prod(A.DB.products[6].id).stock===st);
ok('20b double cancel blocked, nothing deleted',!!A.cancelOrder(o3.id,'x').error&&A.DB.ledger.filter(e=>e.oid===o3.id).length===2);
ok('20c cash cancel creates reversal',!A.cancelOrder(oc,'t').error&&A.DB.ledger.some(e=>e.type==='cash_reversal'));
// pending
const pd=draft('ek kilo atta');pd.cid='c2';pd.pay='credit';const bp=A.bal('c2');const po=A.createOrder(pd,'Pending').order;
ok('pending order does not touch ledger',A.bal('c2')===bp);ok('confirming pending posts exactly once',!A.confirmPending(po.id).error&&A.bal('c2')===bp+4000&&!!A.confirmPending(po.id).error);
// historical price
const hp=A.DB.orders.find(o=>o.items[0].name==='Rice').items[0].price;A.prod(A.DB.products[0].id).price=9900;ok('4/historical price preserved',A.DB.orders.find(o=>o.items[0].name==='Rice').items[0].price===hp);
// money precision
ok('integer paise: 0.1+0.2',A.totalP([{qty:1,price:10},{qty:1,price:20}])===30&&A.toP('19.99')===1999);
// persistence
A.save();const snap=JSON.parse(JSON.stringify(A.DB));ok('21 persistence round-trip',snap.orders.length===A.DB.orders.length&&snap.ledger.length===A.DB.ledger.length);
console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
