# Openly (v2): voice-first order and udhaar management for kirana stores

Single-page app: `index.html` (no build step). Deploy by pushing to GitHub and importing the repo in Vercel (framework: Other).

## Run
- Open `index.html` in Chrome/Edge, or `npx serve .` and open the URL (mic needs https or localhost).
- Logic tests: `node tests/logic.test.js`

## Implemented
Dashboard (range filters, 7/30-day charts, top products, pending payments, low stock), Voice Orders (typed + browser speech recognition, editable draft, clarifications, pending drafts), Orders (search/filter, detail, complete, cancel with reversal, receipts), Customers (validated phone, archive instead of delete), Khata (ledger with running balance, payments, advances, receipts), Products & Inventory (aliases, prices, stock, deactivate), Reports (cash vs credit, daily, top products, CSV, print/PDF), Settings (shop, low-stock threshold, backup/restore JSON).
Money is stored as integer paise. Ledger entries are never edited or deleted; cancellations add reversal entries. An audit trail is kept.

## NOT implemented (needs a backend)
- FastAPI + PostgreSQL, shop accounts/login, multi-shop isolation, server-side audio storage.
- Whisper / GPT extraction. API keys must never be in frontend code, so this needs a server route.
- Voice here = browser speech recognition + rule-based parser (labelled as such in the UI).
- Data lives in browser localStorage. Use Settings → Export backup.
- Excel export (CSV provided). Only nav/headings are translated; page content is English.
